(() => {
  const MIN_SIZE = 280; // abaikan thumbnail/avatar kecil
  const GAP = 14;       // jarak tombol dari tepi video
  let currentEl = null;

  const btn = document.createElement("button");
  btn.id = "wasd-btn";
  btn.title = "Unduh status ini";
  btn.innerHTML =
    '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
    'stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">' +
    '<g class="wasd-arrow"><path d="M12 3v11"/><path d="M7 10l5 5 5-5"/></g>' +
    '<path d="M4.5 20h15"/></svg><span>Unduh</span>';

  const toast = document.createElement("div");
  toast.id = "wasd-toast";
  document.documentElement.append(btn, toast);

  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 2200);
  }

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    if (r.width < MIN_SIZE || r.height < MIN_SIZE) return false;
    if (r.bottom < 0 || r.top > innerHeight || r.right < 0 || r.left > innerWidth) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none" && cs.opacity !== "0";
  }

  function srcOf(el) {
    return el.currentSrc || el.src || el.querySelector?.("source")?.src || "";
  }

  // Ambil media blob terkecil yang masih besar (= video/gambar utama,
  // bukan latar blur yang memenuhi layar)
  function findMedia() {
    const els = [...document.querySelectorAll("video, img")].filter((el) => {
      return srcOf(el).startsWith("blob:") && isVisible(el);
    });
    if (!els.length) return null;
    els.sort((a, b) => {
      const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
      return ra.width * ra.height - rb.width * rb.height;
    });
    return els[0];
  }

  // Taruh tombol di samping kanan video; kalau tidak muat, di dalam tepi kanan
  function place() {
    if (!currentEl) return;
    const r = currentEl.getBoundingClientRect();
    const w = btn.offsetWidth || 120;
    let left = r.right + GAP;
    if (left + w > innerWidth - 8) left = Math.max(8, r.right - w - GAP);
    const top = Math.max(8, r.top + 10);
    btn.style.transform = "";
    btn.style.left = Math.round(left) + "px";
    btn.style.top = Math.round(top) + "px";
  }

  function refresh() {
    currentEl = findMedia();
    btn.style.display = currentEl ? "flex" : "none";
    place();
  }

  const ts = () => {
    const d = new Date(), p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  };

  const EXT = {
    "video/mp4": "mp4", "video/webm": "webm", "video/3gpp": "3gp",
    "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif",
  };

  async function download() {
    if (!currentEl) return;
    const src = srcOf(currentEl);
    btn.classList.add("wasd-busy");
    try {
      const res = await fetch(src);
      const blob = await res.blob();
      if (!blob.size) throw new Error("kosong");
      const kind = currentEl.tagName === "VIDEO" ? "video" : "image";
      const ext = EXT[blob.type] || (kind === "video" ? "mp4" : "jpg");
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `wa-status-${ts()}.${ext}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      showToast("Tersimpan: " + a.download);
    } catch (e) {
      console.error("[WA Status Downloader]", e);
      showToast("Gagal mengunduh. Tunggu media selesai dimuat lalu coba lagi.");
    } finally {
      btn.classList.remove("wasd-busy");
    }
  }

  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    e.preventDefault();
    download();
  });

  let timer;
  new MutationObserver(() => {
    clearTimeout(timer);
    timer = setTimeout(refresh, 150);
  }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["src"] });
  addEventListener("resize", refresh);
  setInterval(refresh, 500);
  refresh();
})();
